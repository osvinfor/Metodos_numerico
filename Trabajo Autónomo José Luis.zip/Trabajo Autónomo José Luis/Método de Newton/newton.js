function solveEquation() {

	const interationsInput = document.getElementById('interations');
	const interations = parseInt(interationsInput.value);

	const result = document.getElementById('result');
	result.innerHTML = '';

	const initialGuess = 10; // Suponemos un valor inicial de x

	let x = initialGuess;
	for (let i = 0; i < interations; i++) {
		x = x - (Math.pow(x, x) - 100) / (Math.pow(x, x) * (Math.log(x) + 1));
		result.innerHTML += `Interación #${i + 1}: x = ${x}<br>`;
	}

	result.innerHTML += `<strong>Resultado Final:</strong> x = ${x}`;
}