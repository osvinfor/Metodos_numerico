function bisectionMethod() {
var resultsContainer = document.getElementById("results");
while (resultsContainer.firstChild) {
	resultsContainer.removeChild(resultsContainer.firstChild);
	}
		var a = parseFloat(document.getElementById("a").value);
		var b = parseFloat(document.getElementById("b").value);
		var interations = parseInt(document.getElementById("interations").value);

	var m, fa, fb, fm;
	for (var i = 1; i <= interations; i++) {
		m = (a + b) / 2;
		fa = Math.pow(a, a) - 100;
		fb = Math.pow(b, b) - 100;
		fm = Math.pow(m, m) - 100;

		var result = document.createElement("p");
		result.innerHTML = "Interación #" + i + ": a = " + a + ", b = " + b + ", m = " + m + ", f(a) = " + fa + ", f(b) = " + fb + ", f(m) = " + fm;
		document.getElementById("results").appendChild(result);

		if (fa * fm < 0) {
		b = m;
		} else {
		a = m;
		}
	}
}